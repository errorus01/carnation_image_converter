fn main() {
    #[cfg(windows)]
    {
        let mut res = winres::WindowsResource::new();
        res.set_icon("carnation_logo.ico");
        if let Err(e) = res.compile() {
            eprintln!("Failed to embed icon: {}", e);
        }
    }
}