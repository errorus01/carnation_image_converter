#![windows_subsystem = "windows"]

use eframe::egui;
use image::imageops::FilterType;
use image::DynamicImage;
use rayon::prelude::*;
use std::io::Cursor;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};
use std::time::Instant;

#[derive(PartialEq, Clone, Copy)]
enum Lang {
    En,
    Ru,
}

#[derive(PartialEq, Clone, Copy, Debug)]
enum TargetFormat {
    Png,
    Jpeg,
    Webp,
    Ico,
    Bmp,
    Tiff,
    Tga,
}

impl TargetFormat {
    fn extension(&self) -> &'static str {
        match self {
            Self::Png => "png",
            Self::Jpeg => "jpg",
            Self::Webp => "webp",
            Self::Ico => "ico",
            Self::Bmp => "bmp",
            Self::Tiff => "tiff",
            Self::Tga => "tga",
        }
    }

    const ALL: &'static [TargetFormat] = &[
        TargetFormat::Png,
        TargetFormat::Jpeg,
        TargetFormat::Webp,
        TargetFormat::Ico,
        TargetFormat::Bmp,
        TargetFormat::Tiff,
        TargetFormat::Tga,
    ];
}

#[derive(PartialEq, Clone, Copy)]
enum ResizeFilter {
    Lanczos3,
    Nearest,
}

#[derive(Clone)]
struct FileItem {
    path: PathBuf,
    name: String,
    size_str: String,
}

struct CarnationApp {
    files: Vec<FileItem>,
    target_format: TargetFormat,
    output_dir: Option<PathBuf>,

    // Ресайз
    enable_resize: bool,
    target_w: u32,
    target_h: u32,
    filter: ResizeFilter,

    lang: Lang,
    status_msg: String,
}

impl Default for CarnationApp {
    fn default() -> Self {
        Self {
            files: Vec::new(),
            target_format: TargetFormat::Ico,
            output_dir: None,
            enable_resize: false,
            target_w: 16,
            target_h: 16,
            filter: ResizeFilter::Lanczos3,
            lang: Lang::Ru,
            status_msg: String::new(),
        }
    }
}

// Загрузка обычного растра или честная векторная растеризация SVG через resvg
fn load_image_or_svg(
    path: &Path,
    enable_resize: bool,
    target_w: u32,
    target_h: u32,
    filter: FilterType,
) -> Result<DynamicImage, Box<dyn std::error::Error + Send + Sync>> {
    let is_svg = path
        .extension()
        .and_then(|e| e.to_str())
        .map(|e| e.eq_ignore_ascii_case("svg"))
        .unwrap_or(false);

    if is_svg {
        let svg_bytes = std::fs::read(path)?;
        let opt = resvg::usvg::Options::default();
        let tree = resvg::usvg::Tree::from_data(&svg_bytes, &opt)?;
        let orig_size = tree.size();

        let (w, h, transform) = if enable_resize && target_w > 0 && target_h > 0 {
            let sx = target_w as f32 / orig_size.width();
            let sy = target_h as f32 / orig_size.height();
            (target_w, target_h, resvg::tiny_skia::Transform::from_scale(sx, sy))
        } else {
            (
                orig_size.width().ceil() as u32,
                orig_size.height().ceil() as u32,
                resvg::tiny_skia::Transform::default(),
            )
        };

        let mut pixmap = resvg::tiny_skia::Pixmap::new(w, h)
            .ok_or("Failed to allocate SVG pixmap")?;
        resvg::render(&tree, transform, &mut pixmap.as_mut());

        let rgba = image::RgbaImage::from_raw(w, h, pixmap.take())
            .ok_or("Failed to create RGBA buffer from SVG")?;
        Ok(DynamicImage::ImageRgba8(rgba))
    } else {
        let img = image::open(path)?;
        if enable_resize && target_w > 0 && target_h > 0 {
            Ok(img.resize_exact(target_w, target_h, filter))
        } else {
            Ok(img)
        }
    }
}

// Сохранение в ICO (мульти-слойный или одиночный)
fn save_as_ico(
    img: &DynamicImage,
    dest_path: &Path,
    enable_resize: bool,
    target_w: u32,
    target_h: u32,
    filter: FilterType,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let mut icon_dir = ico::IconDir::new(ico::ResourceType::Icon);

    if enable_resize && target_w > 0 && target_h > 0 {
        let w = target_w.min(256);
        let h = target_h.min(256);
        let resized = img.resize_exact(w, h, filter);

        let mut png_buf = Vec::new();
        resized.write_to(&mut Cursor::new(&mut png_buf), image::ImageFormat::Png)?;
        let icon_img = ico::IconImage::read_png(Cursor::new(png_buf))?;
        icon_dir.add_entry(ico::IconDirEntry::encode(&icon_img)?);
    } else {
        let sizes = [256, 128, 64, 48, 32, 16];
        for &s in &sizes {
            let resized = img.resize_exact(s, s, FilterType::Lanczos3);
            let mut png_buf = Vec::new();
            if resized
                .write_to(&mut Cursor::new(&mut png_buf), image::ImageFormat::Png)
                .is_ok()
            {
                if let Ok(icon_img) = ico::IconImage::read_png(Cursor::new(png_buf)) {
                    if let Ok(entry) = ico::IconDirEntry::encode(&icon_img) {
                        icon_dir.add_entry(entry);
                    }
                }
            }
        }
    }

    let file = std::fs::File::create(dest_path)?;
    icon_dir.write(file)?;
    Ok(())
}

impl CarnationApp {
    fn add_files(&mut self, paths: Vec<PathBuf>) {
        for path in paths {
            if let Ok(meta) = std::fs::metadata(&path) {
                let name = path
                    .file_name()
                    .unwrap_or_default()
                    .to_string_lossy()
                    .to_string();
                let kb = meta.len() as f64 / 1024.0;
                let size_str = if kb >= 1024.0 {
                    format!("{:.2} MB", kb / 1024.0)
                } else {
                    format!("{:.1} KB", kb)
                };

                self.files.push(FileItem {
                    path,
                    name,
                    size_str,
                });
            }
        }
    }

    fn convert_all(&mut self) {
        if self.files.is_empty() {
            return;
        }

        let target_format = self.target_format;
        let output_dir = self.output_dir.clone();
        let enable_resize = self.enable_resize;
        let (w, h) = (self.target_w, self.target_h);
        let filter = match self.filter {
            ResizeFilter::Lanczos3 => FilterType::Lanczos3,
            ResizeFilter::Nearest => FilterType::Nearest,
        };

        let total = self.files.len();
        let success_count = Arc::new(AtomicUsize::new(0));
        let last_error = Arc::new(Mutex::new(None));

        let success_counter = success_count.clone();
        let error_holder = last_error.clone();

        let start_time = Instant::now();

        // Параллельный процессинг пачки
        self.files.par_iter().for_each(|item| {
            match load_image_or_svg(&item.path, enable_resize, w, h, filter) {
                Ok(img) => {
                    let target_dir = match &output_dir {
                        Some(dir) => dir.clone(),
                        None => item
                            .path
                            .parent()
                            .unwrap_or_else(|| Path::new(""))
                            .to_path_buf(),
                    };

                    let stem = item.path.file_stem().unwrap_or_default().to_string_lossy();
                    let new_filename = format!("{}.{}", stem, target_format.extension());
                    let dest_path = target_dir.join(new_filename);

                    let res = if target_format == TargetFormat::Ico {
                        save_as_ico(&img, &dest_path, enable_resize, w, h, filter)
                    } else {
                        img.save(&dest_path).map_err(|e| e.into())
                    };

                    match res {
                        Ok(_) => {
                            success_counter.fetch_add(1, Ordering::Relaxed);
                        }
                        Err(e) => {
                            let mut err_guard = error_holder.lock().unwrap();
                            *err_guard = Some(format!("{}: {}", item.name, e));
                        }
                    }
                }
                Err(e) => {
                    let mut err_guard = error_holder.lock().unwrap();
                    *err_guard = Some(format!("{}: {}", item.name, e));
                }
            }
        });

        let finished = success_count.load(Ordering::Relaxed);
        let elapsed = start_time.elapsed().as_secs_f32();
        let err_opt = last_error.lock().unwrap().clone();

        if let Some(err) = err_opt {
            self.status_msg = match self.lang {
                Lang::En => format!("Done {}/{}. Error: {}", finished, total, err),
                Lang::Ru => format!("Готово {}/{}. Ошибка: {}", finished, total, err),
            };
        } else {
            self.status_msg = match self.lang {
                Lang::En => format!("Converted {}/{} files in {:.2}s!", finished, total, elapsed),
                Lang::Ru => format!("Сконвертировано {}/{} файлов за {:.2}с!", finished, total, elapsed),
            };
        }
    }
}

impl eframe::App for CarnationApp {
    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        let lang = self.lang;

        // Панель управления
        egui::Panel::left("control_panel")
            .min_size(280.0)
            .show(ui, |ui| {
                // Шапка
                ui.horizontal(|ui| {
                    ui.heading("Carnation");
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        ui.selectable_value(&mut self.lang, Lang::Ru, "RU");
                        ui.selectable_value(&mut self.lang, Lang::En, "EN");
                    });
                });

                ui.separator();

                // Кнопки добавления/очистки
                ui.horizontal(|ui| {
                    let add_text = match lang {
                        Lang::En => "+ Add Images",
                        Lang::Ru => "+ Добавить фото",
                    };
                    if ui.button(add_text).clicked() {
                        if let Some(paths) = rfd::FileDialog::new()
                            .add_filter(
                                "Images",
                                &[
                                    "png", "jpg", "jpeg", "webp", "bmp", "ico", "tiff", "tga",
                                    "svg",
                                ],
                            )
                            .pick_files()
                        {
                            self.add_files(paths);
                        }
                    }

                    let clear_text = match lang {
                        Lang::En => "Clear List",
                        Lang::Ru => "Очистить список",
                    };
                    if ui.button(clear_text).clicked() {
                        self.files.clear();
                        self.status_msg.clear();
                    }
                });

                ui.separator();

                // Выбор формата
                let format_lbl = match lang {
                    Lang::En => "Target Format:",
                    Lang::Ru => "Целевой формат:",
                };
                ui.label(format_lbl);
                egui::ComboBox::from_id_salt("target_format")
                    .selected_text(format!("{:?}", self.target_format).to_uppercase())
                    .show_ui(ui, |ui| {
                        for &fmt in TargetFormat::ALL {
                            ui.selectable_value(
                                &mut self.target_format,
                                fmt,
                                format!("{:?}", fmt).to_uppercase(),
                            );
                        }
                    });

                ui.separator();

                // Блок ресайза
                let resize_chk = match lang {
                    Lang::En => "Resize / Downscale",
                    Lang::Ru => "Изменить разрешение",
                };
                ui.checkbox(&mut self.enable_resize, resize_chk);

                if self.enable_resize {
                    ui.horizontal(|ui| {
                        ui.label("W:");
                        ui.add(egui::DragValue::new(&mut self.target_w).range(1..=16384));
                        ui.label("H:");
                        ui.add(egui::DragValue::new(&mut self.target_h).range(1..=16384));
                    });

                    let filter_lbl = match lang {
                        Lang::En => "Filter:",
                        Lang::Ru => "Фильтр сжатия:",
                    };
                    ui.label(filter_lbl);
                    ui.horizontal(|ui| {
                        let l_smooth = match lang {
                            Lang::En => "Smooth",
                            Lang::Ru => "Плавный",
                        };
                        let l_pixel = match lang {
                            Lang::En => "Pixel-Art",
                            Lang::Ru => "Пиксель",
                        };
                        ui.radio_value(&mut self.filter, ResizeFilter::Lanczos3, l_smooth);
                        ui.radio_value(&mut self.filter, ResizeFilter::Nearest, l_pixel);
                    });
                }

                ui.separator();

                // Папка сохранения
                let out_lbl = match lang {
                    Lang::En => "Output Folder:",
                    Lang::Ru => "Папка сохранения:",
                };
                ui.label(out_lbl);

                let dir_display = match &self.output_dir {
                    Some(dir) => dir
                        .file_name()
                        .unwrap_or_default()
                        .to_string_lossy()
                        .to_string(),
                    None => match lang {
                        Lang::En => "(Same as source)".to_string(),
                        Lang::Ru => "(Рядом с исходниками)".to_string(),
                    },
                };
                ui.label(format!("Path: {}", dir_display));

                ui.horizontal(|ui| {
                    let sel_dir_btn = match lang {
                        Lang::En => "Select Folder",
                        Lang::Ru => "Выбрать папку",
                    };
                    if ui.button(sel_dir_btn).clicked() {
                        if let Some(dir) = rfd::FileDialog::new().pick_folder() {
                            self.output_dir = Some(dir);
                        }
                    }

                    if self.output_dir.is_some() && ui.button("Reset").clicked() {
                        self.output_dir = None;
                    }
                });

                ui.separator();
                ui.add_space(8.0);

                // Кнопка конвертации
                let convert_btn_text = match lang {
                    Lang::En => format!("Convert All ({})", self.files.len()),
                    Lang::Ru => format!("Конвертировать все ({})", self.files.len()),
                };

                let can_convert = !self.files.is_empty();
                if ui
                    .add_enabled(can_convert, egui::Button::new(convert_btn_text))
                    .clicked()
                {
                    self.convert_all();
                }

                if !self.status_msg.is_empty() {
                    ui.separator();
                    ui.label(&self.status_msg);
                }
            });

        // Центральная зона — список файлов в очереди
        egui::ScrollArea::vertical().show(ui, |ui| {
            if self.files.is_empty() {
                ui.centered_and_justified(|ui| {
                    let hint = match lang {
                        Lang::En => "Add images or SVG to start converting",
                        Lang::Ru => "Добавь изображения или SVG для конвертации",
                    };
                    ui.label(hint);
                });
            } else {
                ui.horizontal(|ui| {
                    ui.heading(match lang {
                        Lang::En => format!("Files in queue: {}", self.files.len()),
                        Lang::Ru => format!("Файлов в очереди: {}", self.files.len()),
                    });
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        let clear_btn = match lang {
                            Lang::En => "Clear All",
                            Lang::Ru => "Очистить всё",
                        };
                        if ui.button(clear_btn).clicked() {
                            self.files.clear();
                            self.status_msg.clear();
                        }
                    });
                });
                ui.separator();

                let mut to_remove = None;

                for (idx, item) in self.files.iter().enumerate() {
                    ui.horizontal(|ui| {
                        if ui.button("x").on_hover_text("Remove").clicked() {
                            to_remove = Some(idx);
                        }
                        ui.label(format!("{}.", idx + 1));
                        ui.label(&item.name);
                        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                            ui.label(&item.size_str);
                        });
                    });
                    ui.separator();
                }

                if let Some(idx) = to_remove {
                    self.files.remove(idx);
                }
            }
        });
    }
}

// Загрузка вшитой иконки
fn load_embedded_icon() -> Option<egui::IconData> {
    let icon_bytes = include_bytes!("../carnation_logo.ico");
    if let Ok(img) = image::load_from_memory(icon_bytes) {
        let rgba = img.to_rgba8();
        let (width, height) = rgba.dimensions();
        return Some(egui::IconData {
            rgba: rgba.into_raw(),
            width,
            height,
        });
    }
    None
}

fn main() -> eframe::Result<()> {
    let mut viewport = egui::ViewportBuilder::default()
        .with_inner_size([900.0, 600.0])
        .with_title("Carnation");

    if let Some(icon) = load_embedded_icon() {
        viewport = viewport.with_icon(icon);
    }

    let native_options = eframe::NativeOptions {
        viewport,
        ..Default::default()
    };

    eframe::run_native(
        "Carnation",
        native_options,
        Box::new(|_cc| Ok(Box::new(CarnationApp::default()))),
    )
}